# XGBoost Flask + Streamlit + MongoDB Project

## Structure:
- `backend/`: Flask app for model inference and MongoDB integration
- `frontend/`: Streamlit UI to interact with the model
- `data/`: Sample dataset and inputs
- `notebooks/`: Jupyter/Colab notebooks for training and SHAP
- `docker/`: Dockerfiles and docker-compose for full stack

## Instructions
Run `docker-compose up --build` to start the full application.
