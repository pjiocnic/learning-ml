
# XGBoost Flask App

This project serves predictions from a trained XGBoost model using a Flask API.

## How to Use

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Run the Flask app:
```
python app.py
```

3. Make a prediction:
```bash
curl -X POST http://127.0.0.1:5000/predict -H "Content-Type: application/json" -d '{"features": [0.02, 18.0, 2.31, 0.0, 0.538, 6.575, 65.2, 4.09, 1.0, 296.0, 15.3, 396.9, 4.98]}'
```

Modify the feature vector to suit your model's expected input.
